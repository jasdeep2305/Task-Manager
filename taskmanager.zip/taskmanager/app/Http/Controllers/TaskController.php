<?php

namespace App\Http\Controllers;

use App\Task;

use Illuminate\Http\Request;

use App\Http\Requests;

class TaskController extends Controller
{

public function index()
   {
      $alltasks=Task::all();
        return view('tasks.index',['tasks'=>$alltasks]);
   }


   /**
    * to create a new task.
    *
    * @return Response
    */

   public function create()
   {
      return view('tasks.create');
   }


   /**
    * Store the newly created task.
    *
    * @return Response
    */

   public function store()
   {
      $alltask=Request::all();
      Task::create($alltask);
	 return redirect()->route('tasks.index');
   }

   /**
    * Display the specified task.
    *
    * @param  int  $id
    * @return Response
    */
   public function show($id)
   {
      $task=task::find($id);
   return view('tasks.show')->with('task',$task);
   }

   /**
    * Edit a task.
    *
    * @param  int  $id
    * @return Response
    */
   public function edit($id)
   {
      $task=Task::find($id);
	return view('tasks.edit')->with('task',$task);
   	   }
   /**
    * Update the task in DataBase.
    *
    * @param  int  $id
    * @return Response
    */
   public function update($id)
   {
      $taskUpdate=Request::all();
   	$task=Task::find($id);
   	$task->update($taskUpdate);
   	return redirect()->route('tasks.index');
   }
   /**
    * Delete a task from DataBase
    *
    * @param  int  $id
    * @return Response
    */
   public function destroy($id)
   {
       Task::find($id)->delete();
   	 return redirect()->route('tasks.index');
   }
    

}

