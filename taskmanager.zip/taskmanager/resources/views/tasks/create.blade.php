@extends('layout.template')
@section('content')
    <h1>Create New Task</h1>
    {!! Form::open(['action' => 'TaskController@store']) !!}
    <div class="form-group">
        {!! Form::label('TaskId', 'TaskId') !!}
        {!! Form::text('taskid',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('TaskDetails', 'TaskDetails:') !!}
        {!! Form::text('taskdetails',null,['class'=>'form-control']) !!}

    </div>
    <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
    {!! Form::close() !!}
@stop