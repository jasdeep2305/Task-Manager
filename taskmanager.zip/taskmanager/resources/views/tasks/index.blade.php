@extends('layout/template')

@section('content')
 <h1>Task Manager</h1>
 <a href="{{url('/tasks/create')}}" class="btn btn-success">Create task</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>TaskId</th>
         <th>TaskDetails</th> 
        <th colspan="3">Actions</th>
     </tr>
     </thead>
     <tbody>
     @foreach ($alltask as $task)

         <tr>
             <td>{{ $task->taskid }}</td>
             <td>{{ $task->taskdetails }}</td>
           
             <td><a href="{{url('tasks',$task->id)}}" class="btn btn-default">Read</a></td>
             <td><a href="{{route('tasks.edit',$task->id)}}" class="btn btn-default">Update</a></td>
             <td>{!! Form::open(['route' => ['tasks.destroy', $task->id], 'method' => 'delete']) !!}
                <input class="btn btn-default col-xs-2" type="submit" value="Delete" />
                {!! Form::close() !!}></td>
             
           </tr>
     @endforeach

     </tbody>

 </table>
@endsection