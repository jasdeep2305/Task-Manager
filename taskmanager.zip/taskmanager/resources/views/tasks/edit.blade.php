@extends('layout.template')
@section('content')
    <h1>Update Task</h1>
    {!! Form::model($task,['method' => 'PUT','route'=>['tasks.update',$task->id]]) !!}
       <div class="form-group">
        {!! Form::label('TaskId', 'TaskId') !!}
        {!! Form::text('taskid',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('TaskDetails', 'TaskDetails:') !!}
        {!! Form::text('taskdetails',null,['class'=>'form-control']) !!}

    </div>
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
    {!! Form::close() !!}
@stop